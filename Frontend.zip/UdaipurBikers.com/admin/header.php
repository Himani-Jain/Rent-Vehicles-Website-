<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

<style>
.background
{
	background:url(image/back.jpg);
	background-repeat:no-repeat;
	background-size:100% 100%;
}

</style>


</head>

<body>
<table width="100%" height="236" border="0">
  <tr class="background">
    <td height="232" align="center" valign="middle"><img src="image/logo.png" width="528" height="68" /></td>
  </tr>
</table>
</body>
</html>