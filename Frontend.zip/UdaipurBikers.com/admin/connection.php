<?php 
$hostname="localhost";
$username="root";
$password="";
$database="udaipurbikers";
mysql_pconnect($hostname,$username,$password) or die(mysql_error());
mysql_select_db($database) or die("Database is not found");




?>