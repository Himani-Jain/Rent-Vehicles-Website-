<!DOCTYPE html>
<html>

<head>


<link href="css/formstyle.css" rel='stylesheet' type='text/css' />
<link href="css/nav.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />

<link href="css/nav.css" rel="stylesheet" type="text/css" media="all"/>
<style>
body
{
	background:url(images/backdrop.jpg);
}
.background
{
	background-image:url(admin/image/back.jpg);

}
</style>
</head>
<body >


	<div class="background">
	  <div class="container">
			 <div class="header">
			       <div class="logo"><a href="index.php"><a href="index.php"><img src="images/logo.png" alt="" width="258" height="49"/></a></div>							 
				  <div class="top-nav">										 
						<label class="mobile_menu" for="mobile_menu">
						<span>Menu</span>
						</label>
						<input id="mobile_menu" type="checkbox">
					   <ul class="nav">
						               
						 <li class="dropdown1"><a href="index.php">Home</a>
							 
						 </li>
                         
			          </ul>
				 </div>
				 <div class="clearfix"></div>
			 </div>
	  </div>	 
 </div>     
	 
<!--banner-->


<h1>CREATE ACCOUNT</h1>
	<!-- main -->
	<div class="main">
		<!--login-profile-->
		
		<!--login-profile-->
		<!--signin-form-->
		<div class="w3">
			<div class="signin-form profile">
				<h3>Login</h3>
				
				<div class="login-form">
					<form action="checklogin.php" method="post" name="login">
						<input type="text" name="email" placeholder="E-mail" required>
						<input type="password" name="password" placeholder="Password" required>
						<div class="tp">
							<input type="submit" value="LOGIN NOW">
						</div>
					</form>
				</div>
				
				<p><a href="#"> Dont have an account?</a></p>
			</div>
		</div>
		<div class="agile">
			<div class="signin-form profile">




<?php
	include "connection.php";
	if(isset($_POST['Register']))
	{

	$qry="insert into signup(name,email,username,password)values('".$_POST['name']."','".$_POST['email']."','".$_POST['username']."','".$_POST['password']."')";

	mysql_query($qry);
	
	echo 	'<script >
		alert("Thanks for Registration");
		window location="afterreg.php";

	</script>';
	}
?>





				<h3>Register</h3>
				
				<div class="login-form">
					<form action="afterreg.php" method="post" name="reg">
                    	<input type="text" name="name" placeholder="Name" required>
						<input type="text" name="email" placeholder="E-mail" required>
						<input type="text" name="username" placeholder="Username" required >
						<input type="password" name="password" placeholder="Password" required >
						<input type="submit" value="Register" name="Register">
					</form>
				</div>
				<p><a href="#"> By clicking register, I agree to your terms</a></p>
			</div>
		</div>
		<div class="clear"></div>
		<!--//signin-form-->	
	</div>
										 
			


</body>
</html>

