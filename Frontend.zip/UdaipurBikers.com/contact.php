<?php 
include "header.php"
?>
<!DOCTYPE html>
<html>

<head>
<link href="css/formstyle.css" rel='stylesheet' type='text/css' />
<style>
body
{
	background:url(images/backdrop.jpg);
}
table {
    width: 50%;
    margin-left: auto;
    margin-right: auto;
}
</style>
</head>

<body >
<br>
<br>

<table width="870" border="5" align="center" cellpadding="0" cellspacing="0" >
   <tr bgcolor="#0099FF">
     <td colspan="4" align="center" bgcolor="#FFFFFF"><h3>CONTACT INFORMATION</h3></td>
  </tr>
   <tr bgcolor="#0099FF">
     <td colspan="4">&nbsp;</td>
  </tr>
   <tr>
     <td colspan="4" bgcolor="#FFFFFF">Shop No 7/8/9, D.M.Singh Compound, Opp Shraddha Tower 3, Near 90FT Road, Thakur complex, Kandivali East. Udaipur 400101</td>
   </tr>
   <tr bgcolor="#0099FF">
     <td colspan="4">&nbsp;</td>
   </tr>
   <tr>
     <td width="864" bgcolor="#FFFFFF"><h5>OPERATIONS</h5>
       <ul>
         <li> Deepak Chandrashekhar(Centre Head)</li>
         <li> +91 7710024032</li>
         <li>deepak@enfieldriders.com</li>
     </ul></td>
     <td width="864" bgcolor="#FFFFFF"><h5>SALES</h5>
       <ul>
         <li> Hussain Jariwala(Sales Head)</li>
         <li> +91 7710024033</li>
         <li>hussain@enfieldriders.com</li>
     </ul></td>
     <td width="864" bgcolor="#FFFFFF"><h5>CUSTOMER SERVICE</h5>
       <ul>
         <li> Shreenivas Patel(Customer Experience Head)</li>
         <li> +91 7710024030</li>
         <li>shreeni@enfieldriders.com</li>
     </ul></td>
     <td width="864" bgcolor="#FFFFFF"><h5>ESCALATIONS, COMPLAINTS &amp; SUGGESTIONS</h5>
       <ul>
         <li> Baljeet Gujral(Managing Director)</li>
         <li> baljeet@enfieldriders.com</li>
     </ul></td>
   </tr>
   <tr>
     <td bgcolor="#FFFFFF"><h5>BUSINESS DEVELOPMENT</h5>
       <ul>
         <li> Rohit Sharma(Senior Manager)</li>
         <li> +91 8433984343</li>
         <li>tours@enfieldriders.com</li>
     </ul></td>
     <td bgcolor="#FFFFFF"><h5>SERVICE STATION</h5>
       <ul>
         <li> Animesh Tripathi(Senior Manager)</li>
         <li> +91 7710024031</li>
         <li>servicestation@enfieldriders.com</li>
     </ul></td>
     <td bgcolor="#FFFFFF"><h5>QUALITY &amp; FEEDBACKS</h5>
       <ul>
         <li> Evaristo Fernandes(Senior Manager)</li>
         <li> +91 7710024034</li>
         <li>support@enfieldriders.com</li>
     </ul></td>
     <td bgcolor="#FFFFFF"><h3>MEDIA RELATION</h3>
       <ul>
         <li> Poornima Gujral(Managing Director)</li>
         <li>poornima@enfieldriders.com</li>
     </ul></td>
   </tr>
   <tr bgcolor="#0099FF">
     <td>&nbsp;</td>
     <td>&nbsp;</td>
     <td>&nbsp;</td>
     <td>&nbsp;</td>
   </tr>
</table>
</body>
</html>

