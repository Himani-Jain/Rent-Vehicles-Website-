
<?php
error_reporting(E_ERROR);
session_start();
include "connection.php";
include "header.php";


if(isset($_GET['action']))
{
	if($_GET['action']=="remove")
	{
		$query3="delete from cart where id=".$_GET['id']." and iduser=\"".$_SESSION['id']."\";";
		mysql_query($query3);
	}
}
else{
$id=$_GET['id'];


//echo $id;
$sum=0;

//$query="select * from product where id=\"".$id."\";";
$query="insert into cart(id,name,maincategory,subcategory,price,details,image) select id,name,maincategory,subcategory,price,details,image from product where id=".$id.";";
//echo $query;
mysql_query($query);
$query="update cart set iduser=\"".$_SESSION['id']."\" where id=\"".$id."\";";
mysql_query($query);}
//$r=mysql_fetch_array($rs);
//echo $r['name'];
?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Bike Shop a Ecommerce Category Flat Bootstarp Responsive Website Template| Cart :: w3layouts</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/form.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="bike Shop Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Roboto:500,900,100,300,700,400' rel='stylesheet' type='text/css'>
<!--webfont-->
<!-- dropdown -->
<script src="js/jquery.easydropdown.js"></script>
<link href="css/nav.css" rel="stylesheet" type="text/css" media="all"/>
<script src="js/scripts.js" type="text/javascript"></script>
<!--js-->

<style>
body
{
	background:url(images/backdrop.jpg);
}
</style>
</head>
<body>
<!--banner-->
<script src="js/responsiveslides.min.js"></script>
<script>  
    $(function () {
      $("#slider").responsiveSlides({
      	auto: false,
      	nav: true,
      	speed: 500,
        namespace: "callbacks",
        pager: true,
      });
    });
  </script>

<!--/banner-->
<div class="cart">
	 <div class="container">
		 <!--<div class="cart-top">
			<a href="index.html"><< home</a>
		 </div>	-->
			
		 <div class="col-md-9 cart-items">
			 <h2>My Shopping Bag (2)</h2>
				<script>$(document).ready(function(c) {
					$('.close1').on('click', function(c){
						$('.cart-header').fadeOut('slow', function(c){
							$('.cart-header').remove();
						});
						});	  
					});
			   </script>
			 <!--<div class="cart-header">
				 <div class="close1"> </div>
				 <div class="cart-sec">
						<div class="cart-item cyc">
							 <img src="images/bik6.jpg"/>
						</div>
					   <div class="cart-item-info">
							 <h3>MOUNTAIN HOPPER(XS R034)<span>Model No: 3578</span></h3>
							 <h4><span>Rs. $ </span>5800.00</h4>
							 <p class="qty">Qty ::</p>
							 <input min="1" type="number" id="quantity" name="quantity" value="1" class="form-control input-small">
					   </div>
					   <div class="clearfix"></div>
						<div class="delivery">
							 <p>Service Charges:: Rs.100.00</p>
							 <span>Delivered in 2-3 bussiness days</span>
							 <div class="clearfix"></div>
				        </div>						
				  </div>
			 </div>-->
			 
			 
			 <?php
			 $query2="select * from cart where iduser=\"".$_SESSION['id']."\"";
			 $rs=mysql_query($query2);
			 while($r=mysql_fetch_array($rs))
			 {
			 	
			 ?>
			 <script>$(document).ready(function(c) {
					$('div[name=<?php echo $r['id']?>]').on('click', function(c){/*
							$('.cart-header2'+<?php //echo $r.['id']?>).fadeOut('slow', function(c){
						$('.cart-header2'+<?php //echo $r.['id']?>).remove();
					});*/
					window.location="cart.php?action=remove&id=<?php echo $r['id']?>"
					});	  
					});
			 </script>
			 
			 
			 <div class="cart-header2">
			 <div class="close2" name="<?php echo $r['id']?>">

				 </div>
				 
				  <div class="cart-sec">
						<div class="cart-item">
							 <img src="<?php echo "admin/productgallery/".$r['image']?>"/>
						</div>
					   <div class="cart-item-info">
							 <h3><?php echo $r['name']?><span><?php echo $r['details']?></span></h3>
							 <h4><?php echo $r['price']?></h4>
							 <p class="qty">Qty ::</p>
							 <input min="1" type="number" id="quantity" name="quantity" value="1" class="form-control input-small">
					   </div>
					   <div class="clearfix"></div>
						<div class="delivery">
							 <p>Service Charges:: Rs.100.00</p>
							 <span>Delivered in 2-3 bussiness days</span>
							 <div class="clearfix"></div>
				        </div>						
				  </div>
			  </div>
			  <?php
			  $array=explode(" ", $r['price']);
			  $str=$array[1];
			  //echo $str;
			  $str=str_replace(",", "", $str);
			  //echo $str;
			  $value=intval($str);
			  $sum=$sum+$value;
			  }
			  ?>		
		 </div>
		 <?php
		 
		 ?>
		 <div class="col-md-3 cart-total">
			 <a class="continue" href="product.php">Continue Shopping</a>
			 <div class="price-details">
				 <h3>Price Details</h3>
				 <span>Total</span>
				 <span class="total"><?php echo $sum?></span>
				 <!--<span>Discount</span>
				 <span class="total">---</span>-->
				 <span>Delivery Charges</span>
				 <span class="total">150.00</span>
				 <div class="clearfix"></div>				 
			 </div>	
			 <h4 class="last-price">TOTAL</h4>
			 <span class="total final"><?php echo $sum+150?></span>
			 <div class="clearfix"></div>
			 <a class="order" href="#">Place Order</a>
			 <!--<div class="total-item">
				 <h3>OPTIONS</h3>
				 <h4>COUPONS</h4>
				 <a class="cpns" href="#">Apply Coupons</a>
				 <p><a href="#">Log In</a> to use accounts - linked coupons</p>
			 </div>-->
			</div>
	 </div>
</div>



</body>
</html>

